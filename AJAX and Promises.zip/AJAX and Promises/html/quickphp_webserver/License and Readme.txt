This application is provided as-is. Visit www.zachsaw.co.cc regularly for support forum and updates.

This application has the following restrictions (by downloading / using, you agree to the following terms and conditions):

    * Not to be redistributed
    * Free version is not to be used for commercial purposes (including developing commercial websites)
    * For commercial use, some fees apply. Visit http://www.zachsaw.co.cc/?pg=quickphp_commercial_license for more info
    * Other standard software EULAs such as http://www.microsoft.com/emic/eulaagreement.mspx.
